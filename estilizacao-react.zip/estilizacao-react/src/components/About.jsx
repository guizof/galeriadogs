import React from "react";
import TextBig from "./TextBig";

export default function About(){
    return(
        <div className="one-column content">
            <TextBig label="Sobre" />
            <p> Isso é um site de galeria de cachorros e gatos fofinhos. Se você não gosta de animais, você é uma má pessoa.</p>
        </div>
    )
}